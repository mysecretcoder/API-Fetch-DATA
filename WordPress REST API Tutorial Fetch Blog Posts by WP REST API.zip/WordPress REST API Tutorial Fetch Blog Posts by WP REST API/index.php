<div>
	<button id="posts-btn">Load Post Data</button>
	<div id="posts-container"></div>
</div>